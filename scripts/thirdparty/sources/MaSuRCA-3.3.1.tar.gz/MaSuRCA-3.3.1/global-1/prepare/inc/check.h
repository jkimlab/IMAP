
extern void *ckalloc(unsigned long long amount);
extern void *ckrealloc(void *p, size_t new_size, size_t old_size);
extern FILE *ckopen(char *name, char *mode);

