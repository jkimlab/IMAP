/*************************************************************************** 
 * Title:          nuc.h 
 * Author:         Haixu Tang 
 * Created:        Jun. 2002 
 * Last modified:  May. 2004 
 * 
 * Copyright (c) 2001-2004 The Regents of the University of California 
 * All Rights Reserved 
 * See file LICENSE for details. 
 ***************************************************************************/ 
int total_nuc = 16; 
char na_name[17] = {'g', 'a', 't', 'c', 
	 'n', 'r', 'y', 'w', 's', 'm', 'k', 'h', 'b', 'v', 'd', 'x'}; 
